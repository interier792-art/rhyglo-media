# Rhyglo Media — Full Deck

Upload `index.html` to a GitHub repo root, then Settings → Pages → Deploy from branch → main / (root).

- Videos are YouTube embeds that autoplay (muted, looping) as soon as their page is shown. Browsers only allow autoplay when muted. Open the site from the GitHub Pages https:// address (not by double-clicking the file) so YouTube accepts the embed.
- Cinematic / Promotion / Marketing Research / Custom Songs: 8 video spaces filled with your 6 videos in order (1,2,3,4,5,6,1,2).
- The Work, In Motion: videos 1–5.
- Our Brand Wall: your 7 logos in the first 7 tiles; 8 tiles are still free for uploads.
- Any video space has a Replace button to swap in your own file.
